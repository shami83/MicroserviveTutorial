package com.example.EmployeeDashBoardService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDashBoardServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDashBoardServiceApplication.class, args);
	}
}
